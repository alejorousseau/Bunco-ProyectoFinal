#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <windows.h>
using namespace std;

#include "componentes/menu.h"
#include "funciones/funciones.h"

int main()
{SetConsoleTitle("Bunco");
    system("Color 0D");
    menu();
    cout << endl;
    system("PAUSE");
	return 0;
}
