#ifndef MENU_H_INCLUDED
#define MENU_H_INCLUDED
#include "unjugador/principal.h"
#include "../funciones/funciones.h"

void menu(){
    while (true){
        system("CLS");
        int opcion = 0;
        cout << endl <<"\t\t\t\t      BUNCO" << endl << "\t  ----------------------------------------------------------";
        cout << endl << "\t\t\t1 - Juego nuevo para un jugador";
        cout << endl << "\t\t\t2 - Juego nuevo para dos jugadores";
        cout << endl << "\t\t\t3 - Mostrar puntuacion mas alta";
        cout << endl << "\t\t\t4 - Modo Simulado";
        cout << endl << "\t\t\t0 - Salir";
        cout << endl << "\t  ----------------------------------------------------------" << endl;
        cout << endl << "\t\tOpcion: ";
        cin >> opcion;

        system("CLS");

        switch (opcion){
        case 1: unJugador();
            break;
        case 2:
            break;
        case 3:
            break;
        case 4:
            break;
        case 0:
            break;
        default: pantallaError();
            break;
        }
    cout << endl;
    }
}

#endif // MENU_H_INCLUDED
