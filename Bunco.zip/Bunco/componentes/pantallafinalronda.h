#ifndef PANTALLAFINALRONDA_H_INCLUDED
#define PANTALLAFINALRONDA_H_INCLUDED

void pantallaFinRonda(int punt, int rond, string nomb);

void pantallaFinRonda(int punt, int rond, string nomb){
    cout << endl << " UN JUGADOR - " << nomb << endl;
    cout << endl << "------------------------------------";
    cout << endl << " Ronda: " << rond << endl;
    cout << endl << " Puntos = " << punt;
    cout << endl << "------------------------------------" << endl;
    cout << endl << " Precione tab para ir a la siguiente ronda" << endl;
    system ("PAUSE");
}


#endif // PANTALLAFINALRONDA_H_INCLUDED
