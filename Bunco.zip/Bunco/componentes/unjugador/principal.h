#ifndef PRINCIPAL_CPP_INCLUDED
#define PRINCIPAL_CPP_INCLUDED
#include "../../funciones/funciones.h"
#include "../pantallafinalronda.h"
#include "componentes/pantallafinalunjugador.h"

void unJugador(){
    system("Color 0A");
    string nombre;
    int puntosTotales = 0, tiradasFallidas = 0,  contadorBuncos = 0;
    cout << endl << "\t\t\t\t  UN JUGADOR" << endl << "\t  ----------------------------------------------------------";
    cout << endl << "\t\t\t     Ingrese su nombre: ";
    cin >> nombre;

    for (int ronda = 1; ronda <= 6; ronda++){
            int puntosPorRonda = 0, tiros = 0;
        while(puntosPorRonda < 21){
            int opcion = 0, dados[3];
            tiros ++;
            tirarDados(dados);
            puntosTotales = puntosTotales + calcularPuntos(dados, ronda);
            puntosPorRonda = puntosPorRonda + calcularPuntos(dados, ronda);
            if (calcularPuntos(dados, ronda) == 0){
                tiradasFallidas = tiradasFallidas + 1;
            }
            contadorBuncos = contadorBuncos + (buncoRonda(dados, ronda)/21);
            system("CLS");
            cout << endl << "  TURNO DE " << nombre;
            cout << " | RONDA N " << ronda << " | PUNTAJE ACUMULADO: " << puntosTotales << " PUNTOS";
            cout << endl << " ----------------------------------------------------------";
            cout << endl << "  VECES QUE OBTUVO BUNCO: " << contadorBuncos;
            cout << endl << " ----------------------------------------------------------";
            cout << endl << "  LANZAMIENTO N " << tiros;
            cout << endl << " ----------------------------------------------------------" << endl;
            cout << endl << "  Ha sacado: " << endl << "  " << dados[0] << " | " << dados[1] << " | " << dados[2];
            cout << endl<< endl << "  ";
            system("PAUSE");
        }
        system("CLS");
        pantallaFinRonda(puntosTotales, ronda, nombre);

    }
    system("CLS");
    pantallaFinalUnJugador(puntosTotales, tiradasFallidas, nombre);

    system("CLS");
}


#endif // PRINCIPAL_CPP_INCLUDED
