#ifndef PANTALLAFINALUNJUGADOR_H_INCLUDED
#define PANTALLAFINALUNJUGADOR_H_INCLUDED

#include "../../../funciones/funciones.h"

void pantallaFinalUnJugador(int ujTotalPuntos, int tiradasFallidas, string nomb){
    cout << endl << " UN JUGADOR - " << nomb << endl;
    cout << endl << "------------------------------------";
    cout << endl << " Puntos totales: " << totalFinal(ujTotalPuntos, tiradasFallidas);
    cout << endl << "------------------------------------" << endl;
    cout << endl;
    system ("PAUSE");
}

#endif // PANTALLAFINALUNJUGADOR_H_INCLUDED
